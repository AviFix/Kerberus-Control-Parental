/*
    by Luigi Auriemma
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock.h>
#include <windows.h>



#define VER         "CONNECT proxy forcer 0.1"  // works only with sockets in synchrounous mode (so NOT Firefox)
#define PROXYIP     "127.0.0.1"     // the IP of the proxy to use
#define PROXYPORT   8123            // the port of the proxy



unsigned int    proxy_ip    = 0;
unsigned short  proxy_port  = 0;



static HMODULE wsock = NULL;
static WINAPI int (*real_connect)(SOCKET s, const struct sockaddr *name, int namelen) = NULL;
static WINAPI int (*real_close)(SOCKET s) = NULL;
static WINAPI int (*real_recv)(SOCKET s, char *buf, int len, int flags) = NULL;
static WINAPI int (*real_send)(SOCKET s, char *buf, int len, int flags) = NULL;



unsigned int str2ip(unsigned char *data) {
    unsigned    a, b, c, d;

    if(!data[0]) return(0);
    sscanf(data, "%u.%u.%u.%u", &a, &b, &c, &d);
    return((a & 0xff) | ((b & 0xff) << 8) | ((c & 0xff) << 16) | ((d & 0xff) << 24));
}



unsigned char *ip2str(unsigned int ip) {
    static unsigned char  data[16];

    sprintf(data, "%hhu.%hhu.%hhu.%hhu",
        (ip & 0xff), ((ip >> 8) & 0xff), ((ip >> 16) & 0xff), ((ip >> 24) & 0xff));
    return(data);
}



unsigned short net16(unsigned short num) {
    int         endian = 1; // big endian

    if(!*(char *)&endian) return(num);
    return((num << 8) | (num >> 8));
}



unsigned int net32(unsigned int num) {
    int         endian = 1; // big endian

    if(!*(char *)&endian) return(num);
    return(((num & 0xff000000) >> 24) |
           ((num & 0x00ff0000) >>  8) |
           ((num & 0x0000ff00) <<  8) |
           ((num & 0x000000ff) << 24));
}



#define htons       net16
#define ntohs       net16
#define htonl       net32
#define ntohl       net32
#define inet_ntoa   ip2str
#define inet_addr   str2ip



void init_myproxocket(void) {   // in this example I use this function for loading the real sockets function in case we want to use them
    char    winpath[MAX_PATH];

    if(wsock) return;

    GetSystemDirectory(winpath, sizeof(winpath));
    strcat(winpath, "\\ws2_32.dll");

    wsock = LoadLibrary(winpath);
    if(!wsock) return;

    real_connect   = (void *)GetProcAddress(wsock, "connect");
    real_close     = (void *)GetProcAddress(wsock, "close");
    real_recv      = (void *)GetProcAddress(wsock, "recv");
    real_send      = (void *)GetProcAddress(wsock, "send");

    proxy_ip    = inet_addr(PROXYIP);
    proxy_port  = htons(PROXYPORT);
}



void free_myproxocket(void) {
    if(wsock) {
        FreeLibrary(wsock);
        wsock = NULL;
    }
}



int myconnect(SOCKET s, const struct sockaddr *name, int namelen) {
    unsigned int    ip;
    unsigned short  port;
    int             cr  = 0,
                    lf  = 0,
                    len;
    unsigned char   buff[100];

    ip   = ((struct sockaddr_in *)name)->sin_addr.s_addr;
    port = ntohs(((struct sockaddr_in *)name)->sin_port);

    // skip local IP, Firefox REQUIRES at least that 127.0.0.1 is not proxified at the beginning
    if(((ip & 0xff) == 127) || ((ip & 0xff) == 192) || ((ip & 0xff) == 10)) return(0);

    ((struct sockaddr_in *)name)->sin_addr.s_addr = proxy_ip;
    ((struct sockaddr_in *)name)->sin_port        = proxy_port;

    len = sprintf(buff,
        "CONNECT %hhu.%hhu.%hhu.%hhu:%hu HTTP/1.0\r\n"
        "\r\n",
        (ip & 0xff), ((ip >> 8) & 0xff), ((ip >> 16) & 0xff), ((ip >> 24) & 0xff),
        port);

    if(real_connect(s, name, namelen) == SOCKET_ERROR) goto quit_error;

    if(real_send(s, buff, len, 0) != len) goto quit_error;

    for(;;) {
        if(real_recv(s, buff, 1, 0) != 1) goto quit_error;
        switch(buff[0]) {
            case '\r': cr++;            break;
            case '\n': lf++;            break;
            default: cr = 0; lf = 0;    break;
        }
        if(lf == 2) break;
    }

    // ignore the return number
    return(1);  // > 0 skips the real connect()... it's REQUIRED Proxocket 0.1.4a or more!!!
quit_error:     // error, restore
    ((struct sockaddr_in *)name)->sin_addr.s_addr = ip;
    ((struct sockaddr_in *)name)->sin_port        = htons(port);
    return(SOCKET_ERROR);
}



BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved) {
    switch(fdwReason) {
        case DLL_PROCESS_ATTACH: {
            DisableThreadLibraryCalls(hinstDLL);
            init_myproxocket(); // put your init here
            break;
        }
        case DLL_PROCESS_DETACH: {
            free_myproxocket(); // put anything to free here
            break;
        }
        default: break;
    }
    return(TRUE);
}

