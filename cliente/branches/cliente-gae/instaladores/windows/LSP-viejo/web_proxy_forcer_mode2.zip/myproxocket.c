/*
    by Luigi Auriemma
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock.h>
#include <windows.h>



#define VER         "web proxy forcer mode2 0.1"
#define PROXYIP     "127.0.0.1"     // the IP of the proxy to use
#define PROXYPORT   8080            // the port of the proxy
#define MAXMYDB     512             // don't need to be big, 2 was more than enough



unsigned int    proxy_ip    = 0;
unsigned short  proxy_port  = 0;
struct {
    SOCKET          s;
    unsigned int    ip;
    unsigned short  port;
} mydb[MAXMYDB]             = {{0,0,0}};
// mydb is required because it's not possible to see what is send() done at the beginning of the connection because
// proxocket can't monitor the connections but the single calls so with this temporary db it's a joke to do the job



unsigned int str2ip(unsigned char *data) {
    unsigned    a, b, c, d;

    if(!data[0]) return(0);
    sscanf(data, "%u.%u.%u.%u", &a, &b, &c, &d);
    return((a & 0xff) | ((b & 0xff) << 8) | ((c & 0xff) << 16) | ((d & 0xff) << 24));
}



unsigned char *ip2str(unsigned int ip) {
    static unsigned char  data[16];

    sprintf(data, "%hhu.%hhu.%hhu.%hhu",
        (ip & 0xff), ((ip >> 8) & 0xff), ((ip >> 16) & 0xff), ((ip >> 24) & 0xff));
    return(data);
}



unsigned short net16(unsigned short num) {
    int         endian = 1; // big endian

    if(!*(char *)&endian) return(num);
    return((num << 8) | (num >> 8));
}



unsigned int net32(unsigned int num) {
    int         endian = 1; // big endian

    if(!*(char *)&endian) return(num);
    return(((num & 0xff000000) >> 24) |
           ((num & 0x00ff0000) >>  8) |
           ((num & 0x0000ff00) <<  8) |
           ((num & 0x000000ff) << 24));
}



#define htons       net16
#define ntohs       net16
#define htonl       net32
#define ntohl       net32
#define inet_ntoa   ip2str
#define inet_addr   str2ip



void init_myproxocket(void) {
    proxy_ip    = inet_addr(PROXYIP);
    proxy_port  = htons(PROXYPORT);
}



void free_myproxocket(void) {
}



int myconnect(SOCKET s, const struct sockaddr *name, int namelen) {
    unsigned int    ip;
    unsigned short  port;
    int             i;

    ip   = ((struct sockaddr_in *)name)->sin_addr.s_addr;
    port = ntohs(((struct sockaddr_in *)name)->sin_port);

    // skip local IP, Firefox REQUIRES at least that 127.0.0.1 is not proxified at the beginning
    if(((ip & 0xff) == 127) || ((ip & 0xff) == 192) || ((ip & 0xff) == 10)) return(0);

    ((struct sockaddr_in *)name)->sin_addr.s_addr = proxy_ip;
    ((struct sockaddr_in *)name)->sin_port        = proxy_port;

    for(i = 0; i < MAXMYDB; i++) {
        if(mydb[i].s) continue;     // already occupied
        mydb[i].s    = s;           // fill the field
        mydb[i].ip   = ip;
        mydb[i].port = port;
        break;
    }
    return(0);
}



unsigned char *mymemichr(unsigned char *buff, int buffsz, unsigned char *string) {
    int             stringsz;
    unsigned char   *p,
                    *l;

    stringsz = strlen(string);
    l = buff + buffsz - stringsz;
    for(p = buff; p <= l; p++) {
        if(!strnicmp(p, string, stringsz)) return(p);   // case insensitive
    }
    return(NULL);
}



int mysend(SOCKET s, u_char **retbuf, int len, int flags) {
    int     i,
            tmplen;
    u_char  *buf = *retbuf, // do NOT touch this
            minime[64],
            *tmp,
            *get,
            *host,
            *hoste;

    for(i = 0; i < MAXMYDB; i++) {
        if(!mydb[i].s) continue;
        if(mydb[i].s != s) continue;
        mydb[i].s   = 0;    // reset it

        // consider the incoming buffer a full HTTP request (ssl, ftp and so on are not supported)

        get = mymemichr(buf, len, " ");
        if(!get) goto quit;
        get++;

        host = mymemichr(buf, len, "\nHost:");
        if(host) {  // in case we change the previous string and forgot it
            for(host = strchr(host, ':') + 1; *host == ' '; host++);
            hoste = mymemichr(host, len - (host - buf), "\r\n");
            if(!hoste) goto quit;
            tmp = mymemichr(host, hoste - host, ":");
            if(tmp) hoste = tmp;
        }
        if(!host || !(hoste - host)) { // in case Host didn't exist or was set to zero
            host  = minime;
            hoste = minime + sprintf(minime,
                "%hhu.%hhu.%hhu.%hhu",
                (mydb[i].ip & 0xff), ((mydb[i].ip >> 8) & 0xff), ((mydb[i].ip >> 16) & 0xff), ((mydb[i].ip >> 24) & 0xff));
        }

        tmp = malloc(7 + (hoste - host) + 1 + 5 + len + 1);   // more than enough
        if(!tmp) goto quit;

        len -= (get - buf); // real length of the rest of the data
        tmplen = sprintf(tmp,
            "%.*shttp://%.*s:%hu",
            get - buf, buf, hoste - host, host, mydb[i].port);
        memcpy(tmp + tmplen, get, len);

        len += tmplen;
        buf = tmp;  // don't worry, proxocket automatically frees it!
        break;
    }

quit:
    *retbuf = buf;  // do NOT touch this
    return(len);
}



BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved) {
    switch(fdwReason) {
        case DLL_PROCESS_ATTACH: {
            DisableThreadLibraryCalls(hinstDLL);
            init_myproxocket(); // put your init here
            break;
        }
        case DLL_PROCESS_DETACH: {
            free_myproxocket(); // put anything to free here
            break;
        }
        default: break;
    }
    return(TRUE);
}


