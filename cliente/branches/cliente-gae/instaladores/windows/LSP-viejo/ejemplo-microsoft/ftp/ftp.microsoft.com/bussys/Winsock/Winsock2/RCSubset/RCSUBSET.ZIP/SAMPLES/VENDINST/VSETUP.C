#include <windows.h>
#include <winsock2.h>


typedef struct _VENDOR_WS2SETUP_OPTIONS
{
    DWORD   dwSize;

    BOOL    bInstallMicrosoftTCP;

    BOOL    bInstallMicrosoftIPX;

    BOOL    bShowWS2SetupUI;

} VENDOR_WS2SETUP_OPTIONS, FAR *LPVENDOR_WS2SETUP_OPTIONS;


BOOL
CALLBACK
DlgProc(
    HWND    hwnd,
    UINT    msg,
    WPARAM  wParam,
    LPARAM  lParam
    );


HINSTANCE   ghDLL;



BOOL
WINAPI
DllMain(
    HINSTANCE   hDLL,
    DWORD       dwReason,
    LPVOID      lpReserved
    )
{
    switch (dwReason)
    {
    case DLL_PROCESS_ATTACH:

        ghDLL = hDLL;

    case DLL_PROCESS_DETACH:

        break;

    }

    return TRUE;
}


VOID
WSAAPI
VendorGetSetupOptions(
    LPVENDOR_WS2SETUP_OPTIONS pOptions
    )
{
    DialogBoxParam(
        ghDLL,
        (LPCSTR)MAKEINTRESOURCE(1),
        (HWND) NULL,
        (DLGPROC) DlgProc,
        (LPARAM) pOptions
        );

    return;
}


LONG
WSAAPI
VendorInstallProvider(
    int (WSAAPI *pfnWSCInstallProvider)()
    )
{
    char buf[64];

    wsprintf (buf, "pfnWSCInstallProvider = x%x", pfnWSCInstallProvider);
    MessageBox (NULL, buf, "VendorInstallProvider: enter",MB_OK);
    return 0;  // return the # providers installed
}


LONG
WSAAPI
VendorInstallNameSpace(
    int (WSAAPI *pfnWSCInstallNameSpace)()
    )
{
    char buf[64];

    wsprintf (buf, "pfnWSCInstallNameSpace = x%x", pfnWSCInstallNameSpace);
    MessageBox (NULL, buf, "VendorInstallProvider: enter",MB_OK);
    return 0;  // return the # name spaces installed
}


VOID
WSAAPI
VendorCompleteWS2Install(
    LONG lResult
    )
{
    char buf[64];

    wsprintf (buf, "lResult=x%x", lResult);
    MessageBox (NULL, buf, "VendorCompleteWS2Install: enter", MB_OK);
    return;
}


BOOL
CALLBACK
DlgProc(
    HWND    hwnd,
    UINT    msg,
    WPARAM  wParam,
    LPARAM  lParam
    )
{
    static LPVENDOR_WS2SETUP_OPTIONS pOptions;

    switch (msg)
    {
    case WM_INITDIALOG:

        CheckDlgButton (hwnd, 55, BST_CHECKED);
        CheckDlgButton (hwnd, 56, BST_CHECKED);
        CheckDlgButton (hwnd, 57, BST_CHECKED);
        pOptions = (LPVENDOR_WS2SETUP_OPTIONS) lParam;
        break;

    case WM_COMMAND:

        if (LOWORD((DWORD)wParam) == IDOK)
        {
            pOptions->bInstallMicrosoftTCP = IsDlgButtonChecked(hwnd, 55);
            pOptions->bInstallMicrosoftIPX = IsDlgButtonChecked(hwnd, 56);
            pOptions->bShowWS2SetupUI =      IsDlgButtonChecked(hwnd, 57);
            EndDialog (hwnd, 0);
            break;
        }

        break;
    }

    return FALSE;
}
