// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (C) 1998  Microsoft Corporation.  All Rights Reserved.
//
// Module:
//      getsetqos.cpp
//
// Abstract:    
//      This file contains the functionality needed to fill in and retrieve a 
//      QOS structure. 
//
// Entry Points:
//      GetQos
//      SetQos 
//
// Author:
//      Barry R. Butterklee

#include "qosevent.h"





static VOID FillQosFlowspecDefault(QOS *pQos, DWORD *cbQosLen, QOS_OPTIONS *pQosOptions);
static BOOL FillQosProviderSpecific(QOS *pQos, DWORD *cbQosLen, QOS_OPTIONS *pQosOptions);





// Abstract
//      Use WSAIoctl(SIO_GET_QOS) to retrieve a QOS structure queued up in the 
//      GQOSSP.  We potentially call WSAIoctl twice, the first time to retrieve 
//      the size of the ProviderSpecific buffer we need to allocate in order to
//      hold all the supplied QOS, RSVP, and POLICY objects.  Only NT5 currently
//      supports querying the GQOSSP for the needed buffer size, on Win98 we
//      must supply a "large" buffer or risk not being able to retrieve all the
//      objects.
//
BOOL GetQos(
    SOCKET  sd,
    BOOL    bQueryBufferSize,
    QOS     *pQos
    )
    {
    DWORD   dwBytesReturned=0;
    DWORD   status;
    DWORD   dwBufferLen = 2048;     // pick a large buffer size


    if (bQueryBufferSize)
        {
        pQos->ProviderSpecific.len = QUERY_PS_SIZE;
        pQos->ProviderSpecific.buf = NULL;
        status = WSAIoctl(sd, SIO_GET_QOS, NULL, 0,
                    pQos, sizeof(QOS), &dwBytesReturned, NULL, NULL);
        if (SOCKET_ERROR == status)
            {
            DWORD dwErr = WSAGetLastError();
            if (WSAEWOULDBLOCK != dwErr)
                printf("GetQos: WSAIoctl(SIO_GET_QOS) - query: %d\n", dwErr);
            return(FALSE);
            }
        else
            {
            dwBufferLen = pQos->ProviderSpecific.len;
            }
        }

    if (!(pQos->ProviderSpecific.buf = (CHAR *)malloc(dwBufferLen)))
        {
        printf("GetQos: malloc: %d\n", GetLastError());
        return(FALSE);
        }

    pQos->ProviderSpecific.len = dwBufferLen;
    status = WSAIoctl(sd, SIO_GET_QOS, NULL, 0,
                   pQos, sizeof(QOS)+pQos->ProviderSpecific.len, &dwBytesReturned,
                   NULL, NULL);
    if (SOCKET_ERROR == status)
        {
        printf("GetQos: WSAIoctl(SIO_GET_QOS) %d\n", WSAGetLastError());
        free((char *)pQos->ProviderSpecific.buf);
        return(FALSE);
        }

    return(TRUE);
    }




// Abstract:
//      Depending upon commandline QoS options, either use some default values
//      (see FillQosDefault) or pick up the QoS data by template name.
//
BOOL SetQos(
    SOCKET          sd, 
    QOS_OPTIONS     *pQosOptions,
    BOOL            bSetQos,
    QOS             *pQos, 
    DWORD           *cbQosLen 
    )
    {
    int nRet;
    WSABUF wsabuf;
    DWORD dwBytes;
    BOOL bError = FALSE;


    // fill in some default values
    if (stricmp(pQosOptions->szTemplate, QOS_DEFAULTNAME) == 0)
        {
        FillQosFlowspecDefault(pQos, cbQosLen, pQosOptions);
        }
    else 
        {       
        ZeroMemory(pQos, sizeof(QOS));// *** don't think I should do this
        ZeroMemory((char *)&wsabuf, sizeof(wsabuf));
        wsabuf.len = strlen(pQosOptions->szTemplate) + 1;
        wsabuf.buf = (char *)malloc(wsabuf.len);
        strcpy(wsabuf.buf, pQosOptions->szTemplate);
        if (!WSAGetQOSByName(sd, &wsabuf, pQos))
            {
            printf("WSAGetQosByName: %d\n", WSAGetLastError());
            bError = TRUE;
            }
        else
            {
            if (pQosOptions->bReceiver)
                pQos->SendingFlowspec   = default_notraffic;        
            else
                pQos->ReceivingFlowspec = default_notraffic;
            *cbQosLen = sizeof(QOS) + pQos->ProviderSpecific.len;
            }
        }

    if (!bError)
        {
        if (pQosOptions->bDisableSignalling)
            {
            pQos->ReceivingFlowspec.ServiceType |= SERVICE_NO_QOS_SIGNALING;
            }

        if (!FillQosProviderSpecific(pQos, cbQosLen, pQosOptions))
            {
            bError = TRUE;
            }
        }

    if (!bError && bSetQos)
        {
        nRet = WSAIoctl(sd, SIO_SET_QOS, (LPVOID)pQos, *cbQosLen, 
            NULL, 0, &dwBytes, NULL, NULL);
        if (SOCKET_ERROR == nRet)
            {
            printf("WSAIoctl:SIO_SET_QOS %d\n", WSAGetLastError());
            bError = TRUE;
            }
        else
            bError = FALSE;
        }

    return(!bError);
    }





// Abstract:
//      Fill in default values for QoS structure.  The default values were
//      simply choosen from existing QOS templates available via WSAGetQosByName.
//      Notice that ProviderSpecific settings are being allowed when picking the 
//      "default" template but not for "well-known" QOS templates.  Also notice 
//      that since data is only flowing from sender to receiver, different 
//      flowspecs are filled in depending upon whether this application is 
//      acting as a sender or receiver.
// 
static VOID FillQosFlowspecDefault(
    QOS             *pQos, 
    DWORD           *cbQosLen, 
    QOS_OPTIONS     *pQosOptions
    )
    {

    if (pQosOptions->bReceiver)
        {
        pQos->ReceivingFlowspec = default_g711;
        pQos->SendingFlowspec   = default_notraffic;        
        }
    else
        {
        pQos->SendingFlowspec   = default_g711;     
        pQos->ReceivingFlowspec = default_notraffic;
        }

    pQos->ProviderSpecific.buf = NULL;
    pQos->ProviderSpecific.len = 0;
    *cbQosLen = sizeof(QOS) + pQos->ProviderSpecific.len;
    return;
    }




// Abstract:
//      Fill in the Provider-specific portion of the QOS structure.  Potentially
//      no provider-specific changes may need to be made or an existing
//      provider-specific buffer may need to be added to and/or changed. 
//
//      *** Currently if a Provider-specific buffer already exists it is not 
//      overwritten and this call will fail.
//
static BOOL FillQosProviderSpecific(
    QOS             *pQos, 
    DWORD           *cbQosLen, 
    QOS_OPTIONS     *pQosOptions
    )
    {
    DWORD cbProviderSpecificLen = 0;


    if (!pQosOptions->bProviderSpecific)
        return(TRUE);

    if (pQosOptions->bReceiver)
        {
        if (0 != pQos->ProviderSpecific.len)
            {
            printf("FillQosProviderSpecific: reallocating existing ProviderSpecific buf not supported\n");
            return(FALSE);
            }
        else if (pQosOptions->bConfirmResv)
            {
            static RSVP_RESERVE_INFO RsvpResv;

            ZeroMemory((char *)&RsvpResv, sizeof(RsvpResv));
            RsvpResv.ObjectHdr.ObjectType = RSVP_OBJECT_RESERVE_INFO;
            RsvpResv.ObjectHdr.ObjectLength = sizeof(RsvpResv);
            RsvpResv.Style = RSVP_DEFAULT_STYLE;
            RsvpResv.ConfirmRequest = 1; 
            RsvpResv.NumPolicyElement = 0;
            RsvpResv.PolicyElementList = NULL;
            RsvpResv.NumFlowDesc = 0;
            RsvpResv.FlowDescList = NULL;
            pQos->ProviderSpecific.len = RsvpResv.ObjectHdr.ObjectLength;
            pQos->ProviderSpecific.buf = (char *)&RsvpResv;
            PrintQos(pQos, "  ");
            return(TRUE);
            }
        else
            return(TRUE);
        }
    else
        {
        if (0 != pQos->ProviderSpecific.len)
            {
            printf("FillQosProviderSpecific: reallocating existing ProviderSpecific buf not supported\n");
            return(FALSE);
            }
        else
            {
            static QOS_PRIORITY QosPriority;

            ZeroMemory((char *)&QosPriority, sizeof(QosPriority));
            QosPriority.ObjectHdr.ObjectType   = QOS_OBJECT_PRIORITY;
            QosPriority.ObjectHdr.ObjectLength = sizeof(QosPriority);
            QosPriority.SendPriority = pQosOptions->SendPriority;
            QosPriority.SendFlags = 0;
            QosPriority.ReceivePriority = 0;
            pQos->ProviderSpecific.len = QosPriority.ObjectHdr.ObjectLength;
            pQos->ProviderSpecific.buf = (char *)&QosPriority;
            PrintQos(pQos, "  ");
            return(TRUE);
            }
        }
    }





