#include <ws2spi.h>
#include <windows.h>
#define STRSAFE_NO_DEPRECATE
#include <strsafe.h>
#include <mswsock.h>
#include <ws2tcpip.h>
#include <mstcpip.h>
#include <winsock2.h>
#include <stdio.h>
#include <stdlib.h>
#include <sporder.h>

