// stdafx.cpp : source file that includes just the standard includes
// EasyParentalControlFireWall.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information
#pragma unmanaged

#include "StdAfx.h"
