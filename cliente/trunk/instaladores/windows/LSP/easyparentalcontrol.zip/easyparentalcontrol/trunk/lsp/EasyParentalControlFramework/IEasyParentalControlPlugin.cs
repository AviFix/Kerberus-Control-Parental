﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EasyParentalControlFramework
{
    public class IEasyParentalControlPlugin
    {
        // name is the class name
        void a()
        {
            //StringBuilder sb;
            //String s = new String(
        }

    }
}
